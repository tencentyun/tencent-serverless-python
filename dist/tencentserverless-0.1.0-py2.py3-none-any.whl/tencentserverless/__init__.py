"""
TENCENT_SERVERLESS_PYTHON VERSION
"""

__version__ = '0.0.9'
